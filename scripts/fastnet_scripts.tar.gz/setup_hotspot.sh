#!/bin/bash
# =============================================================================
#  FastNet Hotspot — Kali Linux
#  Internet source : WiFi (wlan0) — untouched, stays connected
#  Hotspot output  : Ethernet (eth0) — clients connect here via AP/switch
#  Runs in FOREGROUND — Ctrl+C to stop cleanly
# =============================================================================
# Usage: sudo bash setup_hotspot.sh
# =============================================================================

# ─────────────────────────────────────────────────────────────
# CONFIGURATION — edit before running
# ─────────────────────────────────────────────────────────────
PORTAL_URL="https://YOUR-APP.replit.app"   # Your deployed Replit portal URL
INET_IFACE="wlan0"                         # Your internet source (WiFi to router)
AP_IFACE="eth0"                            # Your output interface (to AP/switch)
AP_SUBNET="192.168.10"
KALI_IP="${AP_SUBNET}.1"
REDIRECT_PORT="8080"
DHCP_START="${AP_SUBNET}.10"
DHCP_END="${AP_SUBNET}.100"
LEASES_FILE="/tmp/fastnet_dnsmasq.leases"
DNSMASQ_PID="/tmp/fastnet_dnsmasq.pid"
REDIRECT_PID="/tmp/fastnet_redirect.pid"
REFRESH_SECS=4                             # How often to refresh the status display
# ─────────────────────────────────────────────────────────────

# ── Colours ──────────────────────────────────────────────────
R='\033[0;31m'; G='\033[0;32m'; Y='\033[1;33m'
B='\033[0;34m'; C='\033[0;36m'; W='\033[1;37m'
DIM='\033[2m'; BOLD='\033[1m'; NC='\033[0m'

# ── Helpers ───────────────────────────────────────────────────
info()    { echo -e "${B}[INFO]${NC} $1"; }
ok()      { echo -e "${G}[ OK ]${NC} $1"; }
warn()    { echo -e "${Y}[WARN]${NC} $1"; }
err()     { echo -e "${R}[ERR ]${NC} $1"; }
die()     { err "$1"; cleanup; exit 1; }

PIDS_TO_KILL=()

# ── Cleanup on Ctrl+C ─────────────────────────────────────────
cleanup() {
  echo ""
  echo -e "${Y}Stopping FastNet...${NC}"

  for pid in "${PIDS_TO_KILL[@]}"; do
    kill "$pid" 2>/dev/null || true
  done

  [[ -f "$DNSMASQ_PID" ]] && kill "$(cat $DNSMASQ_PID)" 2>/dev/null || true
  pkill -f "fastnet_redirect_inline" 2>/dev/null || true

  # Remove iptables rules
  iptables -t nat -D POSTROUTING -o "$INET_IFACE" -j MASQUERADE 2>/dev/null || true
  iptables -t nat -D PREROUTING -i "$AP_IFACE" -p tcp --dport 80 \
    -j DNAT --to-destination "${KALI_IP}:${REDIRECT_PORT}" 2>/dev/null || true
  iptables -t nat -D PREROUTING -i "$AP_IFACE" -p tcp --dport 443 \
    -j DNAT --to-destination "${KALI_IP}:${REDIRECT_PORT}" 2>/dev/null || true
  iptables -F CAPTIVE_WHITELIST 2>/dev/null || true
  iptables -D FORWARD -i "$AP_IFACE" -j CAPTIVE_WHITELIST 2>/dev/null || true
  iptables -D FORWARD -i "$AP_IFACE" -j DROP 2>/dev/null || true
  iptables -D FORWARD -m state --state ESTABLISHED,RELATED -j ACCEPT 2>/dev/null || true

  echo 0 > /proc/sys/net/ipv4/ip_forward 2>/dev/null || true
  ip addr flush dev "$AP_IFACE" 2>/dev/null || true

  # Restore NM management of AP interface
  nmcli device set "$AP_IFACE" managed yes 2>/dev/null || true

  rm -f "$DNSMASQ_PID" "$REDIRECT_PID"

  echo -e "${G}FastNet stopped. Interfaces restored.${NC}"
  exit 0
}
trap cleanup SIGINT SIGTERM

# ═══════════════════════════════════════════════════════════════
# PRE-FLIGHT CHECKS
# ═══════════════════════════════════════════════════════════════
clear
echo -e "${G}${BOLD}"
echo "  ███████╗ █████╗ ███████╗████████╗███╗   ██╗███████╗████████╗"
echo "  ██╔════╝██╔══██╗██╔════╝╚══██╔══╝████╗  ██║██╔════╝╚══██╔══╝"
echo "  █████╗  ███████║███████╗   ██║   ██╔██╗ ██║█████╗     ██║   "
echo "  ██╔══╝  ██╔══██║╚════██║   ██║   ██║╚██╗██║██╔══╝     ██║   "
echo "  ██║     ██║  ██║███████║   ██║   ██║ ╚████║███████╗   ██║   "
echo "  ╚═╝     ╚═╝  ╚═╝╚══════╝   ╚═╝   ╚═╝  ╚═══╝╚══════╝   ╚═╝   "
echo -e "${NC}"
echo -e "${DIM}  Hotspot Captive Portal Controller${NC}"
echo ""

[[ $EUID -ne 0 ]] && die "Run as root: sudo bash $0"

if [[ "$PORTAL_URL" == "https://YOUR-APP.replit.app" ]]; then
  die "Edit PORTAL_URL at the top of the script with your actual Replit URL."
fi

# Check interfaces exist
ip link show "$INET_IFACE" &>/dev/null || die "Internet interface '$INET_IFACE' not found. Run: ip link show"
ip link show "$AP_IFACE"   &>/dev/null || die "AP interface '$AP_IFACE' not found. Run: ip link show"

# Check internet on INET_IFACE
info "Checking internet connectivity on $INET_IFACE..."
if ping -I "$INET_IFACE" -c 1 -W 3 8.8.8.8 &>/dev/null; then
  ok "Internet is UP on $INET_IFACE"
else
  warn "Cannot reach internet on $INET_IFACE — double-check WiFi is connected"
fi

# ═══════════════════════════════════════════════════════════════
# INSTALL DEPENDENCIES
# ═══════════════════════════════════════════════════════════════
info "Checking dependencies..."
MISSING=()
for pkg in hostapd dnsmasq python3; do
  command -v $pkg &>/dev/null || MISSING+=($pkg)
done
if [[ ${#MISSING[@]} -gt 0 ]]; then
  info "Installing: ${MISSING[*]}"
  apt-get update -qq && apt-get install -y "${MISSING[@]}" > /dev/null 2>&1
fi
ok "Dependencies ready."

# ═══════════════════════════════════════════════════════════════
# TELL NetworkManager TO IGNORE AP INTERFACE ONLY
# ═══════════════════════════════════════════════════════════════
info "Telling NetworkManager to ignore $AP_IFACE (keeping $INET_IFACE managed)..."
nmcli device set "$AP_IFACE" managed no 2>/dev/null || true
sleep 1
ok "NetworkManager: $INET_IFACE still managed, $AP_IFACE handed off."

# ═══════════════════════════════════════════════════════════════
# CONFIGURE AP INTERFACE
# ═══════════════════════════════════════════════════════════════
info "Setting up $AP_IFACE with IP $KALI_IP..."
ip addr flush dev "$AP_IFACE"
ip addr add "${KALI_IP}/24" dev "$AP_IFACE"
ip link set "$AP_IFACE" up
ok "$AP_IFACE is up at $KALI_IP"

# ═══════════════════════════════════════════════════════════════
# DNSMASQ — DHCP + DNS for AP clients
# ═══════════════════════════════════════════════════════════════
info "Starting dnsmasq (DHCP + DNS)..."
pkill -f "dnsmasq.*fastnet" 2>/dev/null || true
sleep 1

DNSMASQ_CONF="/tmp/fastnet_dnsmasq.conf"
cat > "$DNSMASQ_CONF" << EOF
interface=${AP_IFACE}
bind-interfaces
no-dhcp-interface=lo
dhcp-range=${DHCP_START},${DHCP_END},255.255.255.0,24h
dhcp-option=3,${KALI_IP}
dhcp-option=6,${KALI_IP}
address=/#/${KALI_IP}
dhcp-leasefile=${LEASES_FILE}
pid-file=${DNSMASQ_PID}
log-facility=/tmp/fastnet_dnsmasq.log
EOF

dnsmasq --conf-file="$DNSMASQ_CONF" || die "dnsmasq failed. Check: dnsmasq --conf-file=$DNSMASQ_CONF --test"
sleep 1
if pgrep -x dnsmasq &>/dev/null; then
  ok "dnsmasq running — DHCP: $DHCP_START to $DHCP_END"
else
  die "dnsmasq failed to start."
fi

# ═══════════════════════════════════════════════════════════════
# IP FORWARDING + NAT
# ═══════════════════════════════════════════════════════════════
info "Enabling IP forwarding and NAT (${AP_IFACE} → ${INET_IFACE})..."
echo 1 > /proc/sys/net/ipv4/ip_forward

iptables -t nat -D POSTROUTING -o "$INET_IFACE" -j MASQUERADE 2>/dev/null || true
iptables -t nat -A POSTROUTING -o "$INET_IFACE" -j MASQUERADE

iptables -D FORWARD -m state --state ESTABLISHED,RELATED -j ACCEPT 2>/dev/null || true
iptables -A FORWARD -m state --state ESTABLISHED,RELATED -j ACCEPT

iptables -F CAPTIVE_WHITELIST 2>/dev/null || true
iptables -X CAPTIVE_WHITELIST 2>/dev/null || true
iptables -N CAPTIVE_WHITELIST

ok "NAT enabled: clients go out through $INET_IFACE"

# ═══════════════════════════════════════════════════════════════
# CAPTIVE PORTAL REDIRECT (iptables)
# ═══════════════════════════════════════════════════════════════
info "Setting up captive portal redirect rules..."
iptables -t nat -D PREROUTING -i "$AP_IFACE" -p tcp --dport 80 \
  -j DNAT --to-destination "${KALI_IP}:${REDIRECT_PORT}" 2>/dev/null || true
iptables -t nat -D PREROUTING -i "$AP_IFACE" -p tcp --dport 443 \
  -j DNAT --to-destination "${KALI_IP}:${REDIRECT_PORT}" 2>/dev/null || true

iptables -t nat -A PREROUTING -i "$AP_IFACE" -p tcp --dport 80 \
  -j DNAT --to-destination "${KALI_IP}:${REDIRECT_PORT}"
iptables -t nat -A PREROUTING -i "$AP_IFACE" -p tcp --dport 443 \
  -j DNAT --to-destination "${KALI_IP}:${REDIRECT_PORT}"

iptables -A INPUT -i "$AP_IFACE" -p udp --dport 67:68 -j ACCEPT
iptables -A INPUT -i "$AP_IFACE" -p udp --dport 53 -j ACCEPT
iptables -A INPUT -i "$AP_IFACE" -p tcp --dport 53 -j ACCEPT
iptables -A INPUT -i "$AP_IFACE" -p tcp --dport "$REDIRECT_PORT" -j ACCEPT

iptables -D FORWARD -i "$AP_IFACE" -j CAPTIVE_WHITELIST 2>/dev/null || true
iptables -D FORWARD -i "$AP_IFACE" -j DROP 2>/dev/null || true
iptables -A FORWARD -i "$AP_IFACE" -j CAPTIVE_WHITELIST
iptables -A FORWARD -i "$AP_IFACE" -j DROP
iptables -A FORWARD -i "$INET_IFACE" -o "$AP_IFACE" -j ACCEPT

ok "Captive portal redirect: all client HTTP/HTTPS → $KALI_IP:$REDIRECT_PORT"

# ═══════════════════════════════════════════════════════════════
# START REDIRECT SERVER (Python, background for this script)
# ═══════════════════════════════════════════════════════════════
info "Starting redirect server on port $REDIRECT_PORT..."
python3 - << PYEOF &
# fastnet_redirect_inline
import sys, os, signal
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import quote

PORTAL = "${PORTAL_URL}"
PORT   = ${REDIRECT_PORT}
LOG    = open("/tmp/fastnet_redirect.log", "a")

class Handler(BaseHTTPRequestHandler):
    def handle_request(self):
        ip = self.client_address[0]
        url = f"{PORTAL}?client_ip={quote(ip)}"
        self.send_response(302)
        self.send_header("Location", url)
        self.send_header("Cache-Control", "no-cache, no-store")
        self.end_headers()
        LOG.write(f"REDIRECT {ip}\n"); LOG.flush()
    do_GET = do_POST = do_HEAD = handle_request
    def log_message(self, *a): pass

HTTPServer(("0.0.0.0", PORT), Handler).serve_forever()
PYEOF
REDIRECT_BG_PID=$!
PIDS_TO_KILL+=($REDIRECT_BG_PID)
sleep 1

if kill -0 $REDIRECT_BG_PID 2>/dev/null; then
  ok "Redirect server running (pid $REDIRECT_BG_PID)"
else
  die "Redirect server failed to start."
fi

# ═══════════════════════════════════════════════════════════════
# UNBLOCK POLLER (background for this script)
# ═══════════════════════════════════════════════════════════════
info "Starting unblock poller (paid users)..."
python3 - << PYEOF &
# fastnet_unblock_inline
import subprocess, time, json, urllib.request, urllib.error

API     = "${PORTAL_URL}/api/sessions/paid-ips"
WIFI    = "${AP_IFACE}"
ETH     = "${INET_IFACE}"
LOG     = open("/tmp/fastnet_unblock.log", "a")
active  = {}

def run(c): subprocess.run(c, shell=True, capture_output=True)

def allow(ip, sid):
    run(f"iptables -I CAPTIVE_WHITELIST -s {ip} -i {WIFI} -j ACCEPT")
    run(f"iptables -I FORWARD -s {ip} -i {WIFI} -o {ETH} -j ACCEPT")
    LOG.write(f"ALLOW {ip} sid={sid}\n"); LOG.flush()

def revoke(ip, sid):
    run(f"iptables -D CAPTIVE_WHITELIST -s {ip} -i {WIFI} -j ACCEPT")
    run(f"iptables -D FORWARD -s {ip} -i {WIFI} -o {ETH} -j ACCEPT")
    LOG.write(f"REVOKE {ip} sid={sid}\n"); LOG.flush()

while True:
    try:
        with urllib.request.urlopen(API, timeout=8) as r:
            paid = {e["sessionId"]: e["ipAddress"] for e in json.loads(r.read()) if e.get("ipAddress")}
        for sid, ip in paid.items():
            if sid not in active:
                allow(ip, sid); active[sid] = ip
        for sid in list(active):
            if sid not in paid:
                revoke(active.pop(sid), sid)
    except: pass
    time.sleep(5)
PYEOF
UNBLOCK_BG_PID=$!
PIDS_TO_KILL+=($UNBLOCK_BG_PID)
sleep 1
ok "Unblock poller running (pid $UNBLOCK_BG_PID)"

# ═══════════════════════════════════════════════════════════════
# LIVE DASHBOARD — runs in foreground
# ═══════════════════════════════════════════════════════════════
STARTED_AT=$(date "+%H:%M:%S")

get_clients() {
  [[ -f "$LEASES_FILE" ]] || { echo "  none yet"; return; }
  local count=0
  while IFS= read -r line; do
    [[ -z "$line" ]] && continue
    local expiry mac ip hostname _
    read -r expiry mac ip hostname _ <<< "$line"
    local paid_ips
    paid_ips=$(iptables -L CAPTIVE_WHITELIST -n 2>/dev/null | awk '{print $4}' | grep -v "^$" | grep -v "source")
    local status="${R}CAPTIVE${NC}"
    echo "$paid_ips" | grep -q "$ip" && status="${G}PAID/ONLINE${NC}"
    echo -e "    ${W}$ip${NC}  ${DIM}$mac${NC}  ${BOLD}${hostname:-unknown}${NC}  [$status]"
    count=$((count+1))
  done < "$LEASES_FILE"
  [[ $count -eq 0 ]] && echo -e "    ${DIM}none yet${NC}"
}

get_recent_redirects() {
  [[ -f /tmp/fastnet_redirect.log ]] || { echo -e "    ${DIM}none yet${NC}"; return; }
  tail -5 /tmp/fastnet_redirect.log | while read -r line; do
    echo -e "    ${C}→${NC} $line"
  done
  [[ $(wc -l < /tmp/fastnet_redirect.log) -eq 0 ]] && echo -e "    ${DIM}none yet${NC}"
}

get_unblock_events() {
  [[ -f /tmp/fastnet_unblock.log ]] || { echo -e "    ${DIM}none yet${NC}"; return; }
  tail -3 /tmp/fastnet_unblock.log | while read -r line; do
    if echo "$line" | grep -q "ALLOW"; then
      echo -e "    ${G}UNBLOCKED${NC}: $line"
    elif echo "$line" | grep -q "REVOKE"; then
      echo -e "    ${R}EXPIRED${NC}: $line"
    fi
  done
  [[ $(wc -l < /tmp/fastnet_unblock.log) -eq 0 ]] && echo -e "    ${DIM}none yet${NC}"
}

check_service() {
  local pid=$1
  kill -0 "$pid" 2>/dev/null && echo -e "${G}RUNNING${NC}" || echo -e "${R}DOWN${NC}"
}

internet_status() {
  ping -I "$INET_IFACE" -c 1 -W 2 8.8.8.8 &>/dev/null \
    && echo -e "${G}CONNECTED${NC}" \
    || echo -e "${R}NO INTERNET${NC}"
}

ap_link_status() {
  local state
  state=$(cat /sys/class/net/"$AP_IFACE"/operstate 2>/dev/null)
  [[ "$state" == "up" ]] && echo -e "${G}UP${NC}" || echo -e "${R}DOWN — plug in AP/switch${NC}"
}

echo ""
echo -e "${G}${BOLD}  All systems running. Ctrl+C to stop.${NC}"
echo ""

# ── Live loop ─────────────────────────────────────────────────
while true; do
  clear
  TIMESTAMP=$(date "+%Y-%m-%d %H:%M:%S")
  WHITELIST_COUNT=$(iptables -L CAPTIVE_WHITELIST -n 2>/dev/null | grep -c "ACCEPT" || echo 0)
  REDIRECT_TOTAL=$(wc -l < /tmp/fastnet_redirect.log 2>/dev/null || echo 0)
  LEASE_COUNT=$(grep -c "" "$LEASES_FILE" 2>/dev/null || echo 0)

  echo -e "${G}${BOLD}  FastNet Hotspot  ${NC}${DIM}$TIMESTAMP  (started $STARTED_AT)${NC}"
  echo -e "  ${DIM}Press Ctrl+C to stop cleanly${NC}"
  echo ""

  echo -e "  ${BOLD}INTERFACES${NC}"
  echo -e "    Internet  (${W}$INET_IFACE${NC}): $(internet_status)"
  echo -e "    AP output (${W}$AP_IFACE${NC}):  $(ap_link_status)"
  echo ""

  echo -e "  ${BOLD}SERVICES${NC}"
  echo -e "    Redirect server  : $(check_service $REDIRECT_BG_PID)  port ${REDIRECT_PORT}"
  echo -e "    Unblock poller   : $(check_service $UNBLOCK_BG_PID)  every 5s"
  echo -e "    DHCP / DNS       : $(pgrep -x dnsmasq &>/dev/null && echo -e "${G}RUNNING${NC}" || echo -e "${R}DOWN${NC}")"
  echo -e "    Captive portal   : ${G}ACTIVE${NC}  →  ${C}${PORTAL_URL}${NC}"
  echo ""

  echo -e "  ${BOLD}CONNECTED CLIENTS${NC}  ${DIM}(${LEASE_COUNT} DHCP leases | ${WHITELIST_COUNT} paid/online)${NC}"
  get_clients
  echo ""

  echo -e "  ${BOLD}RECENT REDIRECTS${NC}  ${DIM}(last 5 — total: ${REDIRECT_TOTAL})${NC}"
  get_recent_redirects
  echo ""

  echo -e "  ${BOLD}UNBLOCK EVENTS${NC}"
  get_unblock_events
  echo ""

  echo -e "  ${DIM}─────────────────────────────────────────────────────────${NC}"
  echo -e "  ${DIM}Whitelisted IPs: $(iptables -L CAPTIVE_WHITELIST -n 2>/dev/null | grep ACCEPT | awk '{print $4}' | paste -sd ',' - || echo 'none')${NC}"
  echo -e "  ${DIM}Refreshing every ${REFRESH_SECS}s...${NC}"

  sleep $REFRESH_SECS
done
